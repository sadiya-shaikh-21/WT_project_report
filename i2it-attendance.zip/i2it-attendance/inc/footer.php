	<div class="container mt-3">
		
			<h3>
				<span>Copyright &copy;</span>
				
				<script type="text/javascript">
					
					var d = new Date();
					
					document.write(d.getFullYear());
				</script>
				
				<span>
					 <b>Developered By</b>
					<a target="_blank" href="https://www.linkedin.com/in/sadiya-shaikh-rafiq/">
						 Sadiya Shaikh, 
					</a>
					
				</span>
			</h3>
		
	</div>
</body>
</html>